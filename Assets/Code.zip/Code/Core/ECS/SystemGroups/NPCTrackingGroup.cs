using Unity.Entities;

public partial class NPCTrackingGroup : ComponentSystemGroup
{
}