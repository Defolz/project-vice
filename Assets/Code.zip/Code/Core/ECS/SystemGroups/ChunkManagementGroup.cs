using Unity.Entities;

public partial class ChunkManagementGroup : ComponentSystemGroup
{
}