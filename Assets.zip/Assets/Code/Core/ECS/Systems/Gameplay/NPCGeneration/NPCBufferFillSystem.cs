using Unity.Burst;
using Unity.Entities;

// Система, заполняющая буферы на основе инструкций из NPCBufferFillInstruction
// Читает NPCBufferEntities для доступа к целевым Entity буферов
[UpdateInGroup(typeof(InitializationSystemGroup))] // Или SimulationSystemGroup
[UpdateAfter(typeof(NPCBufferCreationSystem))]
public partial struct NPCBufferFillSystem : ISystem
{
    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        var ecbSingleton = SystemAPI.GetSingletonRW<EndInitializationEntityCommandBufferSystem.Singleton>(); // Используем End для Destroy/Remove
        var ecb = ecbSingleton.ValueRW.CreateCommandBuffer(state.WorldUnmanaged);

        foreach (var (fillInstruction, bufferEntities, entity) in SystemAPI.Query<RefRO<NPCBufferFillInstruction>, RefRO<NPCBufferEntities>>().WithEntityAccess())
        {
            var instruction = fillInstruction.ValueRO;
            var buffers = bufferEntities.ValueRO; // Теперь получаем из NPCBufferEntities

            // Получаем буферы с инструкциями
            var scheduleInstructionBuffer = state.EntityManager.GetBuffer<TimeSlot>(instruction.ScheduleInstructionsBufferEntity);
            var relationshipsInstructionBuffer = state.EntityManager.GetBuffer<RelationshipEntry>(instruction.RelationshipsInstructionsBufferEntity);

            // Получаем буферы, которые нужно заполнить
            var scheduleBuffer = state.EntityManager.GetBuffer<TimeSlot>(buffers.ScheduleBufferEntity); // <-- Из NPCBufferEntities
            var relationshipsBuffer = state.EntityManager.GetBuffer<RelationshipEntry>(buffers.RelationshipsBufferEntity); // <-- Из NPCBufferEntities

            // Заполняем целевые буферы из буферов инструкций
            foreach (var slot in scheduleInstructionBuffer)
            {
                scheduleBuffer.Add(slot);
            }

            foreach (var entry in relationshipsInstructionBuffer)
            {
                relationshipsBuffer.Add(entry);
            }

            // Удаляем временные Entity с инструкциями и компонент инструкций
            ecb.DestroyEntity(instruction.ScheduleInstructionsBufferEntity);
            ecb.DestroyEntity(instruction.RelationshipsInstructionsBufferEntity);
            ecb.RemoveComponent<NPCBufferFillInstruction>(entity);
        }
    }
}