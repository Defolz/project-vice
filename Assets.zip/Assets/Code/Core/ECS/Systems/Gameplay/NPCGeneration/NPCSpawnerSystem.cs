using Unity.Burst;
using Unity.Entities;

// Система, фактически добавляющая окончательные компоненты NPC из NPCSpawnData
// и удаляющая NPCSpawnData и NPCBufferEntities
// Читает NPCBufferEntities для доступа к Entity буферов
[UpdateInGroup(typeof(InitializationSystemGroup))] // Или SimulationSystemGroup
[UpdateAfter(typeof(NPCBufferFillSystem))] // Обновляем порядок
public partial struct NPCSpawnerSystem : ISystem
{
    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        var ecbSingleton = SystemAPI.GetSingletonRW<EndInitializationEntityCommandBufferSystem.Singleton>(); // Используем End для Remove
        var ecb = ecbSingleton.ValueRW.CreateCommandBuffer(state.WorldUnmanaged);

        // Итерируемся по NPCSpawnData и NPCBufferEntities
        foreach (var (spawnDataRO, bufferEntitiesRO, entity) in SystemAPI.Query<RefRO<NPCSpawnData>, RefRO<NPCBufferEntities>>().WithEntityAccess())
        {
            var data = spawnDataRO.ValueRO;
            var buffers = bufferEntitiesRO.ValueRO; // Получаем Entity буферов из NPCBufferEntities

            // Добавляем компоненты к Entity NPC
            state.EntityManager.AddComponentData(entity, data.Id);
            state.EntityManager.AddComponentData(entity, data.Name);
            state.EntityManager.AddComponentData(entity, data.Location);
            state.EntityManager.AddComponentData(entity, data.Faction);
            state.EntityManager.AddComponentData(entity, new Schedule(buffers.ScheduleBufferEntity)); // <-- Используем Entity из NPCBufferEntities
            state.EntityManager.AddComponentData(entity, data.Goal);
            state.EntityManager.AddComponentData(entity, data.States);
            state.EntityManager.AddComponentData(entity, data.Traits);
            state.EntityManager.AddComponentData(entity, new Relationships(buffers.RelationshipsBufferEntity)); // <-- Используем Entity из NPCBufferEntities

            // Удаляем временные компоненты после обработки
            ecb.RemoveComponent<NPCSpawnData>(entity);
            ecb.RemoveComponent<NPCBufferEntities>(entity); // <-- Удаляем NPCBufferEntities
        }
    }
}